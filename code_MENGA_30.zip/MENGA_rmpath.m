
%=======================================================================
%						-MENGA rmpath
%=======================================================================
pwpath = fileparts(which('MENGA.m'));
phwd = fullfile(pwpath, 'code','DataProcessing');
rmpath(phwd);
phwd = fullfile(pwpath, 'code','UTILITY');
rmpath(phwd);

fprintf('MENGA path removed\n\n');

%_______________________________________________________________________
% @(#)MENGA    King's College & UNIPD - May 2015
 




