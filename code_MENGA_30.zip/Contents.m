% Write text describing the m-files in this directory
%  
% MENGA            		    -   Main driver 
% MENGA_farewell            -   Exit function
% MENGA_GUI                 -   Graphic User Interface
% MENGA_rmpath              -   Path removal script for MENGA
% MENGA_run                 -   Main of MENGA (load data and run analysis)
% MENGA_setpath             -   Path setting script for MENGA
% MENGA_setsetting          - 	Routine to select MENGA settings
% MENGA_welcome             -   Welcome script
%_______________________________________________________________________
% @(#)MENGA    King's College & UNIPD - May 2015