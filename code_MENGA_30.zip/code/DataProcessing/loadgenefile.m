% loadgenefile: creates cell array with the gene list to be analysed
% input:
% namegene: string, filename of txt file with list of genes
% output: 
% genelabel: cell array, format: genelabel{x} =['name'];

function genelabel = loadgenefile(namegene)
% Read lines from input file

fid=fopen(namegene);
k = 1;
while ~feof(fid)
    curr = fscanf(fid,'%s',1);
    genelabel{k}=curr;
    k = k+1;
end
    
fclose(fid);
