% loading genomic data for correlation

% input:
% mockfolder: string, contains the PLATFORM (including folders code, data
% and TEMPLATE)
% genelabel: cell array, it contains the labels of the genes to load.
% listroi: cell array, it contains the regions to create the macroroi

% output:
% gen2don: structure (size: 6x1)
%   - donor: string, label donor
%   - exp: 2D matrix [nr gene x nr roi], contains the average values of
% expression in the rois in listroi for all the genes listed in genelabel
%   - expstd: 2D matrix [nr gene x nr roi], contains the standard deviation
% values of the expression samples in the rois in listroi for each gene
%   - expnr: 2D matrix [nr gene x nr roi], contains the number of samples
% in the rois in listroi for each gene
%   - expval: 2D cell array [nr gene x nr roi], contains all the sample
% values contained in the rois in listroi for each gene
%   - info: struct, it contains the information of the genomic import:
%       - gene_name: cell array, it contains the genes loaded
%       - listroi: cell array, contains the list of rois
%       - probe_corr: 1D matrix, contains the average Pearson's correlation
%       r of the chosen probes with all the excluded

% note: data are loaded in log2 and then converted in 2^VALUES

function gen2don = LoadGenomicDataGenomicPlot(mockfolder,genelabel,listroi)

%% importing genomic data from MockABA
mockfolder = fullfile(mockfolder,'data');

%% DIRECTORY and SUBJ DEFINITION
listsubj = dir(fullfile(mockfolder,'donor*'));
nsubj = size(listsubj,1);

%% mapping genomic data for each donor

for i=1:nsubj
    %% load single sample labels
    code = listsubj(i).name(6:end);
    load(fullfile(mockfolder,listsubj(i).name,['Mapping_',num2str(code)]))
    iCoarse = cell2mat(Mapping(:,1));
    iStructure = cell2mat(Mapping(:,3));
    iSample = cell2mat(Mapping(:,5));
    
    %% loading all the gene requested
    exp = zeros(size(genelabel,2),length(iSample));
    
    for k = 1:size(genelabel,2)
        
        genelab = genelabel{k};
        
        %% filename definition
        genefolder = fullfile(mockfolder,listsubj(i).name,'Gene_expression',genelab);
        namefile = fullfile(genefolder,[genelab,'_probes.csv']); % data in log2
        namestat = fullfile(genefolder,[genelab,'_stats.txt']);
        
        % info stores the information related to the gene loaded
        [datacorr(k,1), probeid] = loadgenestat(namestat);
        genename{k,1} = genelab;
        
        % load data in log2 in the form: [idprobe SAMPLES]
        temp = importdata(namefile);
        % temp contains ALL the probes = we need the correct probe (from
        % *stats.txt)
        id = find(temp(:,1)==probeid);
        datalog = temp(id,2:end);
        datalin = 2.^datalog;
        exp(k,:) = datalin;
        clear temp
    end
    
    info.probe_corr = datacorr;
    info.gene_name = genename;
    info.listroi = listroi;
    
    %% save samples
    nrstr = length(listroi); % nr of final structures
    expmean = zeros(size(exp,1),nrstr);
    expstd = zeros(size(exp,1),nrstr);
    expnum = zeros(size(exp,1),nrstr);
    
    for j=1:nrstr
        roi = listroi{j}; % if I want a region made up by combination of micro/macro-roi (es, thalamus)
        iroi = union(union(find(ismember(iCoarse,roi)),find(ismember(iStructure,roi))),find(ismember(iSample,roi)));
        % unreliable genomic values are set to NaN = not included in the
        % mean ==> nanmean
        expmean(:,j) = nanmean(exp(:,iroi),2);
        expstd(:,j) = nanstd(exp(:,iroi),[],2);
        expval{j} = exp(:,iroi);
        % number of elements in each region, after removing NaN
        expnum(:,j) = sum(~isnan(exp(:,iroi)),2);
    end
    
    gen2don(i).donor = listsubj(i).name;
    gen2don(i).exp = expmean;
    gen2don(i).expstd = expstd;
    gen2don(i).expnr = expnum;
    gen2don(i).expval = expval;
    gen2don(i).info = info;
    
    clear expval
    clear exp
    clear info
    disp(['Gene list for donor ',num2str(i), ' loaded.'])
end

