% loading imaging data for correlation in single donor space

% The values returned are in z-score

% input:
% mockfolder: string, contains the PLATFORM (including folders code, data
% and TEMPLATE)
% imagefolder: string, folder with ONE image to load (either Analyze of
% NIfTI)
% listroi: cell array, it contains the regions to create the macroroi
% window size: integer, dimension of the window to calculate the image
% sample
% mask: 3D matrix, [1 NaN], optional. If not present, default is:
% MASK_MNI_brain_imfill
%   The mask must have values either 1 (voxel to be included) or NaN (voxel
%   to be excluded)
% we deci
% output:
% img2don: structure (size: 6x1)
%   - label: string, label donor
%   - exp: 2D matrix [nr image x nr roi], contains the average values of
% image in the rois in listroi for all the image listed in imagefolder
%   - expstd: 2D matrix [nr image x nr roi], contains the standard deviation
% values of the image samples in the rois in listroi for each image
%   - expnr: 2D matrix [nr image x nr roi], contains the number of samples
% in the rois in listroi for each image
%   - expval: 2D cell array [nr image x nr roi], contains all the sample
% values contained in the rois in listroi for each image
%   - info: struct, it contains the information of the genomic import:
%       - image_name: cell array, it contains the images loaded
%       - Mapping: cell array, it contains all the donors' information
%       (mainly for sample/structure/coarse labels and XYZ coordinates)
%       - listroi: cell array, contains the list of rois


% note: samples out of the mask are set to NaN - data are already in Z-SCORE


function img2don = MappingImage2DonorsGenomicPlot(mockfolder,imagefolder,listroi,windowsize,mask)


%% import imaging data
foldercont = [dir(fullfile(imagefolder,'*nii')); dir(fullfile(imagefolder,'*img')); dir(fullfile(imagefolder,'*gz'));];

if isempty(foldercont)
    img2don = [];
    return
end

%% LOAD IMAGE DATA
nrimage = size(foldercont,1);
for j = 1:nrimage
    img = loadimageGenomicPlot(imagefolder,foldercont(j).name,mask);
    imgdataset(:,:,:,j) = img;
    image_name{j} = foldercont(j).name;
end

%% DIRECTORY and SUBJ DEFINITION
mockfolder = fullfile(mockfolder,'data');
listsubj = dir(fullfile(mockfolder,'donor*'));
nsubj = size(listsubj,1);

for s=1:nsubj
    %%
    % change subject directory and load genomic data
    code = listsubj(s).name(6:end);
    load(fullfile(mockfolder,listsubj(s).name,['Mapping_',num2str(code)]))
    % MNI coordinates extraction
    MNI = [Mapping(:,8:10)];
    MNI = cell2mat(MNI);
    % conversion in XYZ coordinates
    XYZ = mni2xyz_coord(MNI);
    info.image_name = image_name;
    info.Mapping = Mapping;
    info.listroi = listroi;
    
    %% importing the image in the space requested
    [expvalues, expstd, expnr, expval] = sampleimg2don(imgdataset,XYZ,windowsize,listroi,Mapping);
    
    img2don(s).label = listsubj(s).name;
    img2don(s).exp = expvalues;
    img2don(s).expstd = expstd;
    img2don(s).expnr = expnr;
    img2don(s).expval = expval;
    img2don(s).info = info;
    
end


