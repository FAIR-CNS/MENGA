% function [im_out] = checksize(im_in)

% the function checks whether the image is (181,217,181) [MRIcro standard)
% or (182,218,182) [FSL standard)
% if in FSL standard, im_out is reduced to MRIcro standard to be aligned
% with genomic information

% input:
% im_in: 3D matrix 

% output:
% im_out: 3D matrix (size: 181, 217, 181)

function [im_out] = checksize(im_in)

dim = size(im_in);

if dim == [181 217 181], 
    im_out = im_in; 
    disp('Image in MNI standard. Size correct');
elseif dim == [182 218 182], 
    im_out = reducesize(im_in);
    disp('Image size in FSL MNI standard, now corrected'),
else
    disp('Image size not in MNI standard. End of program.')
    im_out = zeros(181,217,181);
    return
end