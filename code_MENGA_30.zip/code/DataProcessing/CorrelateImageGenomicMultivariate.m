% Crosscorrelation: squared correlation R^2
%
% input:
% img2don: structure
% gen2don: structure
% pval: boolean, true/false: if true, calculate the p-value associated to
% the R2
%
% output:
% sqcor: 1D matrix, containing the cross-correlation. Size nrgene x 1
% (there is only one value for 6 donors vs 1 image)
% direc: 1D matrix, containing the directionality. Size nrgene x 1
% (there is only one value for 6 donors vs 1 image)
% pvalue: 1D matrix, containing the chance likelihood
% newdata: 2D matrix, with the data used for the correlation, as [GENOMIC -
% MEAN IMAGE - IMAGE], size nrroi x 13
% It can be used both at sample or structure/coarse level.

function [sqcor, pvalue, newdata, direc] = CorrelateImageGenomicMultivariate(img2don,gen2don,pval)

dimgene = size(gen2don(1).exp,1);
% dimimg = size(img2don(1).exp,1);
nrdonor = size(gen2don,2);
sqcor = zeros(1,dimgene);
direc = zeros(1,dimgene);
pvalue = zeros(1,dimgene);
varpca = 95; % threshold on percentage of variance of PCA (95%)

for k=1:dimgene
    X=[];
    nROI = length(gen2don(1).exp(1,:));
    % regress
    for j=1:nrdonor
        X(:,j) = gen2don(j).exp(k,:)';
        Y(:,j) = img2don(j).exp(1,:)';
        nrsam(:,j) = img2don(j).expnr(1,:)';
        imgstd(:,j) = img2don(j).expstd(1,:)';
    end
    YY = nanmean(Y,2);
    % define NaN
    iokIm = find(~isnan(YY)); % it is sufficient to eliminate those regions with all NaN
    % for genomic
    for j=1:nrdonor
        iokGene(:,j) = ~isnan(X(:,j));
    end
    iokGene = sum(iokGene,2); % if no NaN == iokGene = nrdonor
    iokGene = find(iokGene==nrdonor);
    iok = intersect(iokIm, iokGene);
    
    YY = YY(iok);
    niok = length(iok);
    
    % PCA to derive the principal components
    [coeff, score, latent, ts, explained] = pca(X(iok,:));
    % coeff: coordinates of each row respect to PC
    % score: PC
    % explained: % of variance explained by each PC
    
    if not(isempty(explained))
        
        % we keep only the PC which explain at least 95% of variance
        tot = explained(1);
        ind = 1;
        while tot<varpca
            ind = ind+1;
            tot = tot+explained(ind);
        end
        nPC = ind;
        PCs = score(:,1:nPC);
        PCs(:,nPC+1) = ones(niok,1);
        
        % weighted regression: weights on MEAN IMAGE:
        % a) mean(nrsample) = the more the nr of samples, the more reliable
        % the region value
        % b) between-subject variability = the smaller variability across
        % resampling, the more reliable the value
        % c) between-subject average of the variability within the region =
        % the smaller the variability, the more constant the value
        w_a = mean(nrsam(iok,:),2);
        w_b = 1./nanstd(Y(iok,:),[],2);
        w_c = 1./mean(imgstd(iok,:),2);
        weights = sqrt(w_a.*w_b);
        weights(isinf(weights))=0;
        
        % calculation of R2
        sqcor(k) = CalculateR2(PCs,YY,weights);
        mslope = polyfit(PCs(:,1).*weights, YY.*weights,1);
        direc(k) = sign(mslope(1));
        
        % p_value
        if pval
            warning off
            nboot = 1000;
            pvalue(k) = CalculateLikelihood(X(iok,:),YY,weights,sqcor(k),nboot);
            
        end
    end
    newdata(:,:,k) = [X(iok,:) YY Y(iok,:)];
end

