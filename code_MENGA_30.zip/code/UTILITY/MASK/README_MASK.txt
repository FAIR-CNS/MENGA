Different masks created for image loading. 

- MASK_MNI_brain_imfill: binary mask built by me in Matlab from MNI T1 of FSL after application of Matlab "imfill '-holes'". 

- MASK_MNI_brain_imfill_left: binary mask MASK_MNI_brain_imfill limited to left hemisphere. 
