
%=======================================================================
%						-MENGA setpath
%=======================================================================
pwpath = fileparts(which('MENGA.m'));
% pwpath = ['\\nas2\biopetmri\BACKUP\cosa_nostra\lavori_PET\Network analysis of mRNA expression\STOLTUS_20_Export'];

addpath(pwpath,'-begin');
phwdProc = fullfile(pwpath, 'code', 'DataProcessing');
addpath(phwdProc,'-begin');
phwdUtility = fullfile(pwpath, 'code', 'UTILITY');
addpath(genpath(phwdUtility),'-begin');

fprintf('MENGA tools added to path\n');

%_______________________________________________________________________
% @(#)MENGA    King's College & UNIPD - May 2015
 




