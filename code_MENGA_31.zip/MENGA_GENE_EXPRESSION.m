% MENGA - add-on GENE EXPRESSION

% Startup routine for MENGA -> add-on GENE EXPRESSION
% Add-on GENE EXPRESSION allows to extract from MENGA database only mRNA
% values (in log2) without needing to select an image and complete the
% integration analysis
%
% MENGA: Multimodal Environment for Neuroimaging and Genomic Analysis
%
% MENGA (the collection of files listed by Contents.m) is copyright under
% the GNU general public license (GPLv3). 
% 
% The transcriptome genomic mRNA data are made freely available by the 
% Allen Institute for Brain Science. Data were downloaded from the Allen 
% Human Brain Atlas (http://human.brain-map.org/, Hawrylycz et al, Nature, 
% 2012).
% 
% MENGA written by 
% Gaia Rizzo, Paul Expert and Mattia Veronese
%
% Version 1.0 
% 2016, April 26th


%
clc
close all
clear 

%=======================================================================
%                   Welcome
%=======================================================================

MENGA_welcome; 

MENGA_setpath;

MENGA_setsetting_GENE_EXPRESSION;

%% DATA LOADING

%importing genomic data
gen2don = LoadGenomicDataLog2(pwpath,genelabel,listroi);
nroi= length(listroi);
nrgene= length(genelabel);
nrdon = size(gen2don,2);


%Processing mRNA
for i=1:nrdon
    for j = 1:nrgene;
        genval(:,i,j) = gen2don(i).exp(j,:);
    end
end

%Print on command window
disp('|-------------------------------------------------------------------|');
disp('|                        GENE EXPRESSION                            |');
disp('|-------------------------------------------------------------------|');
%TABLE
for j=1:nrgene
    TAB_GEN(:,:,j) = [mean(genval(:,:,j),2) std(genval(:,:,j),[],2)];
    fprintf('\n%s\t\t%s\t%s',cell2mat(genelabel(j)),'MEAN','SD');
    for i=1:nroi
        fprintf('\n%s\t%2.3f\t%2.3f',cell2mat(namelistroi(i)),TAB_GEN(i,1,j),TAB_GEN(i,2,j));
    end
    fprintf('\n');
end

%% SAVING 
% SAVE in pathgene, creating a folder
fileResults = ['GENE_EXPRESSION_',char(filegene(1:end-4))]; % need to eliminate the extension
folderResults = fullfile(pathgene,fileResults);
mkdir(folderResults);

% SAVE mat
filename = fullfile(folderResults,[fileResults,'.mat']);
save(filename,'gen2don','genelabel','listroi','namelistroi','genval','TAB_GEN')

% WRITE TXT OUTPUT FILE

fid = fopen([fullfile(folderResults,fileResults),'.txt'],'w');

fprintf(fid,['MENGA: Multimodal Environment for Neuroimaging and Genomic Analysis - add-on GENE EXPRESSION\n']);
lic = importdata('MENGA_licence.txt');
fprintf(fid,['Version ',num2str(lic),'\n\n']);

fprintf(fid,[fileResults,'\n\n']);
fprintf(fid,['SETTINGS: \n']);
fprintf(fid,['Number of regions: ',num2str(nroi),'\n']);
fprintf(fid,['Region list: ',fileroi,'\n\n']);

fprintf(fid,'Genomic raw data in log2 \n');

fprintf(fid,'\n');

for i=1:nrgene
    fprintf(fid,[num2str(i),'. Gene ',genelabel{i},'\n']);
    
    singledata = genval(:,:,i);
    rawdata = singledata(:,1:nrdon);
    fprintf(fid,'%d %s %d %s \n',size(rawdata,1),'ROIs for', size(gen2don,2),'donors');
    
    for j=1:size(rawdata,1)
        name = namelistroi{j};
        fprintf(fid,'%s %.3f %.3f %.3f %.3f %.3f %.3f \n', name, rawdata(j,:));
    end
    fprintf(fid,'\n');
    clear rawdata
end

fclose(fid);

%% rmpath
disp('|-------------------------------------------------------------------|');
disp('|                        END OF ANALYSIS                            |');
disp('|-------------------------------------------------------------------|');

%=======================================================================
%				-remove path
%=======================================================================
MENGA_rmpath;


%=======================================================================
%    				 Farewell
%=======================================================================
MENGA_farewell;
close all force

%_______________________________________________________________________
% @(#)MENGA    King's College & UNIPD - April 2016



