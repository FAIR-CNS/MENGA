|===================================================================|
|                        WELCOME to MENGA                           |
|                                                                   |
|                                                                   |
|    Multimodal Environment for Neuroimaging and Genomic Analysis   |
|                                                                   |
|===================================================================|
 
       Created by Gaia Rizzo, Paul Expert & Mattia Veronese
 
               mRNA data source: Allen Human Brain Atlas 
                 (http://human.brain-map.org/)
 
--------------------------------------------------------------------
 
INTRODUCTION:
MENGA is a software package for the integration of genomic and imaging data written for Matlab 2012b and following (The Mathworks Inc., MA, USA).
Although it has been designed on a Windows platform, it can be used on any other OS like Unix or Linux where the Matlab package is installed.

GETTING STARTED:
Once the program is unpackaged in its directory, start Matlab. Use the �current directory� tab to go to the MENGA directory and type
>>MENGA

The menubar and the logo should appear.

INPUT files:
REGION LIST 	- mat file, with the list of ROIs (as ABA labels) to use for the integration. Libraries available.
MASK 			- mat file, brain mask from FSL. Libraries available.
IMAGE FOLDER 	- folder, containing all the images (Analyze or NIfTI files) to be analysed.
GENE LIST 		- txt file, with the list of genes (as described in Allen Brain website).
WINDOW SIZE 	- integer, window size for the image import.


%_______________________________________________________________________
% @(#)MENGA    King's College & UNIPD - Dec 2015