% Crosscorrelation: squared correlation R^2
%
% input:
% img2don: structure
% gen2don: structure
%
% output:
% stat: 2D matrix, 5 x nrgene with mean/SD/CV/min/max of correlation values
% sqcor: 3D matrix, containing the cross-correlation between genes and
% image. 6 x 6 x nrgenes.
% direc: 2D matrix, values 1 where there is positive correlation
% between image and gene. 6 x nrgenes (1 where positive, 1 where negative).
% It can be used both at sample or structure/coarse level.
% NOTE: there is only one image => dimimg = 1;

function [stat, sqcor, direc] = CorrelateImageGenomic(img2don,gen2don)

dimgene = size(gen2don(1).exp,1);
% dimimg = size(img2don(1).exp,1);
nrdonor = size(gen2don,2);
sqcor = zeros(size(gen2don,1),dimgene);
direc = zeros(size(gen2don,1),dimgene);
stat = zeros(5,dimgene);

for k=1:dimgene
    X=[];
    nROI = length(gen2don(1).exp(1,:));
    % regress
    for j=1:nrdonor
        iok = (~isnan(gen2don(j).exp(k,:))&~isnan(img2don(j).exp(1,:)));
        niok = length(find(iok));
        if not(any(iok)),continue,end
        X = gen2don(j).exp(k,iok)';
        Y = img2don(j).exp(1,iok)';
        nrsam = img2don(j).expnr(1,iok)';
        imgstd = img2don(j).expstd(1,iok)';
        % weighted regression: weights on IMAGE:
        % a) nrsample = the more the nr of samples, the more reliable
        % the region value
        % b)  variability within the region = the smaller the
        % variability, the more constant the value
        w_a = nrsam;
        w_b = 1./imgstd;
        weights = sqrt(w_a.*w_b);
        % if there is one sample = STD is zero = weights is INF
        weights(isinf(weights))=0;
        
        G = [X ones(niok,1)].*repmat(weights, 1,2);
        
        warning('off','MATLAB:nearlySingularMatrix')
        
        x = inv(G'*G)*G'*(Y.*weights);
        
        SStot = sum((Y-mean(Y)).^2);
        SSres = sum((Y-[X ones(niok,1)]*x).^2);
        sqcor(j,k) = 1-SSres/SStot;
        mslope = polyfit(X.*weights, Y.*weights,1);
        direc(j,k) = sign(mslope(1));
    end
    
end

% Calculate statistics
% in this case it is OK to assess only value > 0
% sqcor is a matrix 6 x nrgene

for k=1:dimgene
    corsing = squeeze(sqcor(:,k));
    if any(corsing>0)
        stat(1,k) = mean(corsing(corsing>0));
        stat(2,k) = std(corsing(corsing>0));
        stat(3,k) = stat(2,k)/stat(1,k)*100;
        stat(4,k) = min(corsing(corsing>0));
        stat(5,k) = max(corsing(corsing>0));
        if any(corsing<0)
            fprintf(['Warning UNIVARIATE correlation: for gene ',num2str(k),' and the image there are ',num2str(length(find(corsing<0))),' negative R-squared','\n'])
        end
    else
        fprintf(['Warning UNIVARIATE correlation: for gene ',num2str(k),' and the image there are NO positive R-squared','\n'])
    end
    clear corsing
end

