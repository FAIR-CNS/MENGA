% calculates the R2 value - adjusted R2

function asqcor = CalculateR2(PCs,YY,weights)

nPC = size(PCs,2)-1;
nsample = size(PCs,1);

G = [PCs.*repmat(weights, 1,nPC+1)];

warning('off','MATLAB:nearlySingularMatrix')

x = inv(G'*G)*G'*(YY.*weights);

SStot = sum((YY-mean(YY)).^2);
SSres = sum((YY-PCs*x).^2);
sqcor = 1-SSres/SStot;

asqcor = 1-(1-sqcor)*((nsample-1)/(nsample-(nPC+1)));
