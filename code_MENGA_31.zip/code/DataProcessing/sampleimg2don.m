% function imgsamples = sampleimg2don(img,XYZ_coord,windowsize,index)

% The function samples the images in the genomic space (of a certain donor)
% defined by the coordinates XYZ. It calculates the "voxel" values
% corresponding to each coordinates, averaging the image values within the
% window (with size windowsize). 

% input:
% img: 4D matrix (rows x columns x slices x nrsubjects)
% XYZ_coord: 2D matrix (size: N x 3), N number of genomic samples. Absolute
% coordinates of the genomic samples of one donor
% windowsize: integer. Values of the window size.
% listroi: cell array, it contains the regions to create the macroroi
% map: cell array, with Mapping (for index of samples, structures and
% coarse rois)

% output:
% imgstr: 2D vector (nrsubjectsxN) with average values
% imgstrstd: 2D vector (nrsubjectsxN) with std values
% sizestr: 2D vector (nrsubjectsxN) with nr of samples in each structure
% strindex: 2D vector (nrsubjectsxN) with roi label
% imgval: 2D cell vector (nrsubjectsxN) with the actual expression values

function [imgstr, imgstrstd, sizestr, imgval] = sampleimg2don(img,XYZ_coord,windowsize,listroi,map)

%% image sampling
dim = size(img);
if length(dim)>3,
    nrsubj = dim(4);
else
    nrsubj = 1;
end
nrsamples = size(XYZ_coord,1);
winside = floor(windowsize/2);
nrstr = length(listroi); % number of macro roi

imgsamples = zeros(nrsubj,nrsamples);
imgstr = zeros(nrsubj,nrstr);
imgstrstd = zeros(nrsubj,nrstr);
sizestr = zeros(nrsubj,nrstr);
%% image 2 samples
% conversion from image to single samples (same size and format of exp)
for s = 1:nrsubj
    imgsing = img(:,:,:,s);
    for i = 1:nrsamples
        % definition of windows of voxels
        rows = XYZ_coord(i,1)-winside:XYZ_coord(i,1)+winside;
        cols = XYZ_coord(i,2)-winside:XYZ_coord(i,2)+winside;
        slices = XYZ_coord(i,3)-winside:XYZ_coord(i,3)+winside;
        % if a sample "falls" out of the image (corner sample) -->
        % discarded --> CONSERVATIVE approach: all the samples are the
        % average of windowsize^3 values
        if any(rows <= 0 | rows > dim(1) | cols <= 0 | cols > dim(2) | slices <= 0 | slices > dim(3))
            imgsamples(s,i) = NaN;
        else
            win = imgsing(rows,cols,slices);
            imgsamples(s,i) = mean(win(:)); % use of mean: if the windows "falls" out of the mask --> automatically set to NaN
        end
    end
    iCoarse = cell2mat(map(:,1));
    iStructure = cell2mat(map(:,3));
    iSample = cell2mat(map(:,5));
    
    %% image 2 structure
    % image data are in samples format --> need to average them in
    % structure/coarse contained in listroi. If NaN are included in the
    % macroroi, the samples are ignored but the roi is kept.
    for j=1:nrstr
        roi = listroi{j}; % if I want a region made up by combination of micro/macro-roi (es, thalamus)
        iroi = union(union(find(ismember(iCoarse,roi)),find(ismember(iStructure,roi))),find(ismember(iSample,roi)));
        imgstr(s,j) = nanmean(imgsamples(s,iroi),2);
        imgstrstd(s,j) = nanstd(imgsamples(s,iroi),[],2);
        % number of elements in each region, after removing NaN
        sizestr(s,j) = sum(~isnan(imgsamples(s,iroi)),2);
        imgval{s,j} = [imgsamples(s,iroi)];
    end
end


