% when more than one image is loaded, it exctract img2don for the single
% image (identified by val)

% input: 
% img2don_full: struct img2don with image values for N>1 image
% val: integer, index of the image to extract

% output: 
% img2don: struct with image values for the single image

function img2don = reduceImg2don(img2don_full,val)

nrdon = size(img2don_full,2);

for i = 1:nrdon
    img2don(i).donor = img2don_full(i).label; 
    img2don(i).exp = img2don_full(i).exp(val,:); 
    img2don(i).expstd = img2don_full(i).expstd(val,:); 
    img2don(i).expnr = img2don_full(i).expnr(val,:); 
    for j=1:size(img2don_full(i).expval,2)
        temp = img2don_full(i).expval{val,j};
        img2don(i).expval{j} = temp; 
    end
    img2don(i).info = img2don_full(i).info; 
    
end
