% checkgenelist: it checks whether the genes listed exist in the Allen
% database. If not, it deletes the entry. If no entries remain, the program
% returns.

% input:
% genelabel: cell array, contains the gene labels
% folderAllen: string, path of MENGA

% output:
% newgenelabel: cell array, updated with only the correct labels

function newgenelabel = checkgenelist(genelabel,folderAllen)


%% folder with Allen database
mockfolder = fullfile(folderAllen,'data');

%% DIRECTORY and SUBJ DEFINITION
listsubj = dir(fullfile(mockfolder,'donor*'));

% check only for first subject: all the donors contain the same folders
i = 1;
cc = 1;
for k = 1:size(genelabel,2)
    % for each gene
    genelab = genelabel{k};
    genefolder = fullfile(mockfolder,listsubj(i).name,'Gene_expression',genelab);
    if exist(genefolder, 'dir')==7 % check whether it finds a directory
        newgenelabel{cc} = genelab;
        cc = cc+1;
    end
end



