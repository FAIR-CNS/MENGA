% function [im_out] = reducesize(im_in)

% the function reduces an image in MNI FSL standard (182 218 182) to MNIcro
% standard (181 217 181) to be aligned with genomic information

% input:
% im_in: 3D matrix (size: 182, 218, 182)

% output:
% im_out: 3D matrix (size: 181, 217, 181)

function [im_out] = reducesize(im_in)

im_out = im_in(2:end,2:end,2:end);

end