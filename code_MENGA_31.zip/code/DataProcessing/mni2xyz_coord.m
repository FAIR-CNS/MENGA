% function XYZ_coord = mni2xyz_coord(MNI_coord)

% the function converts the MNI coordinates (referred to a 181 217 181
% image) to absolute XYZ coordinates.
% The offset is fixed and equal to (91, 126, 72)

% input:
% MNI_coord: 2D matrix (size: Nx3)

% output:
% XYZ_ooord: 2D matrix (size: Nx3) 

function XYZ_coord = mni2xyz_coord(MNI_coord)

offset = [91 126 72];
dim = size(MNI_coord);
XYZ_coord = MNI_coord+repmat(offset,dim(1),1);
XYZ_coord = round(XYZ_coord);

end