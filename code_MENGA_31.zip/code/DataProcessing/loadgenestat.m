% loadgenestats load the AVERAGE value of Pearson's correlation r of the
% selected probe with the other probes
% it also returns the ID of the selected probe for the gene profile

function [datacorr, probeid] = loadgenestat(namestats)
% Read lines from input file

data = importdata(namestats,'\n');

% the information is located on line 3, just after '#Correlation Average
% correlation of group 1 with other probes: '. In case it changes =
% uncomment line 13 and comment line 14
% row_idx = find(~cellfun('isempty',strfind(data,'#Correlation Average correlation of group 1 with other probes: ')));
row_idx = 3;

% the number is located after ':'. In case it changes, comment line 19 and
% uncomment line 18
% ch_idx = strfind(data{row_idx},': ');
ch_idx = 63;
num = data{row_idx}(ch_idx+1:end);
datacorr = str2double(num);

% the information is located on line 6, just after '#Probes_1_idnbr'
row_idx = 6;
% the number is located after ' ' (space). In case it changes, comment line 28 and
% uncomment line 27
% ch_idx = strfind(data{row_idx},' ');
ch_idx = 16;
num = data{row_idx}(ch_idx+1:end);
probeid = str2double(num);

