% It prints on the command windows the results statistics

% input:
% tabgene: 2D matrix of statistics on correlation of genes, 5 x nrgenes
% tabimg: 1D matrix of statistics on correlation of the image, 5 x 1
% tabuni: 2D matrix of statistics on univariate correlation, 5 x nrgenes
% tabmulti: 1D matrix of statistics on multivariate correlation, 5 x 1
% pvalue: 1D likelihood chance, 5 x 1
% genelabel: string with gene list
% tabautogene: 3D matrix with correlation values for all genes, 6 x 6 x nr
% gene
% gen2don: struct with the expression values
% newdata: 2D matrix, with the data used for the correlation, as [GENOMIC -
% MEAN IMAGE - IMAGE], size nrroi x (nrdonorx2+1) x nrgene
% fileResults: string with name of file to be saved
% folderResults: string with name of folder to save results
% namelistroi: cell array with the name of the regions of interest
% filemask: string, name of mask used
% fileroi: string, name of list of regions
% windowsize: integer, size of window
% direc: 2D matrix with directionality of univariate correlation, 6 x
% nrgenes
% direcMulti: 2D matrix with directionality of multivariate correlation, 1
% x nrgenes

function saveResults(tabgene,tabimg,tabuni,tabmulti,pvalue,genelabel,tabautogene,gen2don,newdata,fileResults,folderResults,namelistroi,filemask,fileroi,windowsize,direc,direcMulti)

%% WRITE TXT OUTPUT FILE

nrgene = size(tabgene,2);
nrdon = size(gen2don,2);
nroi = size(namelistroi,2);
fid = fopen([fullfile(folderResults,fileResults),'.txt'],'w');

fprintf(fid,['MENGA: Multimodal Environment for Neuroimaging and Genomic Analysis \n']);
lic = importdata('MENGA_licence.txt');
fprintf(fid,['Version ',num2str(lic),'\n\n']);

fprintf(fid,[fileResults,'\n\n']);
fprintf(fid,['SETTINGS: \n']);
fprintf(fid,['Number of regions: ',num2str(nroi),'\n']);
fprintf(fid,['Region list: ',fileroi,'\n']);
fprintf(fid,['Image name: ',fileResults(9:end),'\n']);
fprintf(fid,['Mask name: ',filemask,'\n']);
fprintf(fid,['Window size: ',num2str(windowsize),'\n\n']);

fprintf(fid,'SUMMARY \n');
fprintf(fid,['The average IMAGE auto-correlation is: ',num2str(tabimg(1,1),3),' +/- ',num2str(tabimg(2,1),3),'\n\n']);

for i=1:nrgene
    fprintf(fid,[num2str(i),'. Gene ',genelabel{i},'\n']);
    fprintf(fid,['The average GENOMIC auto-correlation is: %.3f +/- %.3f \n'],tabgene(1,i),tabgene(2,i));
    fprintf(fid,['The average UNIVARIATE cross-correlation is: %.3f +/- %.3f \n'],tabuni(1,i),tabuni(2,i));
    fprintf(fid,['\t Direction of the univariate correlation: +1 (%d/6), -1 (%d/6)','\n'],length(find(direc(:,i)>0)),length(find(direc(:,i)>0)));
    fprintf(fid,['The MULTIVARIATE cross-correlation is: %.3f (chance likelihood = %2.0f%%)','\n'],tabmulti(1,i),pvalue(1,i)*100);
    fprintf(fid,['\t Direction of the multivariate correlation: %+.0f\n\n'],direcMulti(i));
end

% autocorrelation matrix is 6 x 6 with 1s on the diagonal and % where
% symmetric

fprintf(fid,'Genomic auto-correlation matrix \n');
for i=1:nrgene
    fprintf(fid,[num2str(i),'. Gene ',genelabel{i},'\n']);
    for row = 1:nrdon
        strVal = '%.3f \t';
        for col = 1:nrdon
            if tabautogene(row,col,i)==0
                strVal = '%% \t';
            end
            fprintf(fid,strVal,tabautogene(row,col,i));
            strVal = '%.3f \t';
        end
        fprintf(fid,'\n');
    end
    fprintf(fid,'\n');
end
%%

fprintf(fid,'Genomic raw data \n');

fprintf(fid,'\n');

for i=1:nrgene
    fprintf(fid,[num2str(i),'. Gene ',genelabel{i},'\n']);
    
    singledata = newdata(:,:,i);
    rawdata = singledata(:,1:nrdon);
    fprintf(fid,'%d %s %d %s \n',size(rawdata,1),'ROIs for', size(gen2don,2),'donors');
    
    %     fprintf(fid,['Donor 1','Donor 2','Donor 3','Donor 4','Donor 5','Donor 6']);
    for j=1:size(rawdata,1)
        name = namelistroi{j};
        fprintf(fid,'%s %.3f %.3f %.3f %.3f %.3f %.3f \n', name, rawdata(j,:));
    end
    fprintf(fid,'\n');
    clear rawdata
end

fclose(fid);

%% PLOT
% A) BARGRAPH

for i=1:nrgene
    h = figure(i);
    val = [tabgene(1,i) tabimg(1,1) tabuni(1,i) tabmulti(1,i)];
    bar(val,0.4);
    ylim([0 1])
    title(gen2don(1).info.gene_name{i})
    set(gca,'XTickLabel',{'auto-corr gene', 'auto-corr image', 'cross-corr univar', 'cross-corr multivar'})
    saveas(gca,fullfile(folderResults,['Statistic_',gen2don(1).info.gene_name{i}]),'eps')
    saveas(gca,fullfile(folderResults,['Statistic_',gen2don(1).info.gene_name{i}]),'fig')
    close
end

% B) SCATTER

for i=1:nrgene
    singledata = newdata(:,:,i);
    X = singledata(:,1:nrdon);
    YY = singledata(:,nrdon+1);
    Y = singledata(:,nrdon+2:end);
    
    h = figure(i);
    subplot(121), plot(YY,X,'*'), xlabel('Mean image [z-score]'), ylabel('Genomic data [z-score]'), title('Cross-consistency (image vs. genomic)')
    subplot(122), plot(YY,Y,'*'), xlabel('Mean image [z-score]'), ylabel('Resampled images [z-score]'), title('Image homogeneity')
    suptitle(gen2don(1).info.gene_name{i})
    saveas(h,fullfile(folderResults,['Correlation_',gen2don(1).info.gene_name{i}]),'eps')
    saveas(h,fullfile(folderResults,['Correlation_',gen2don(1).info.gene_name{i}]),'fig')
    close
    
end
