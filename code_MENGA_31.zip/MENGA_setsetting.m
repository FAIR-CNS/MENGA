% MENGA_SETSETTING
disp(' ')
disp('|-------------------------------------------------------------------|')
disp('|                        SELECT SETTING                             |');
disp('|-------------------------------------------------------------------|')

%% LOAD RISTROI
%listroi
[fileroi, pathname] = uigetfile('*.mat', 'Select region list for the analysis',fullfile(phwdUtility,'LISTROI','listroi.mat'));
if isequal(fileroi,0)
    load('listroi.mat')
    disp('Default region list loaded')
else
    disp(['User selected ', fullfile(pathname, fileroi)])
    load(fullfile(pathname, fileroi))
end

%% MASK
%mask
% NOTE: mask is ALWAYS loaded in this step - default: MASK_MNI_brain_imfill_LEFT
[filemask, pathname] = uigetfile('*.mat', 'Select mask for the analysis',fullfile(phwdUtility,'MASK','MASK_MNI_brain_imfill_LEFT.mat'));
if isequal(filemask,0)
    load('MASK_MNI_brain_imfill_LEFT.mat')
    disp('Default region list loaded')
else
    disp(['User selected ', fullfile(pathname, filemask)])
    load(fullfile(pathname, filemask))
end


%% WINDOWS SIZE
%window size
prompt = {'Enter windows size (positive integer):'};
dlg_title = 'Window size';
num_lines = 1;
def = {'5'};
windowsize = inputdlg(prompt,dlg_title,num_lines,def);
windowsize = str2num(cell2mat(windowsize));

%% IMAGE INPUT DATA
start_path = pwd; % current folder - working directory
folderImage = uigetdir(start_path,'Select folder of the image to analyze');

%% GENE  INPUT DATA
% NOTE: THERE MUST BE A GENE FILE. IF NOT = EXIT
[filename, pathname] = uigetfile('*.txt', 'Select gene list for the analysis',phwdUtility);
if isequal(filename,0)
    disp('No gene list file loaded: exiting MENGA...')
    MENGA_rmpath;
    MENGA_farewell;
    break
else
    disp(['User selected ', fullfile(pathname, filename)])
end

% create gene list file as: format: genelabel{x} =['name'];
genelabel = loadgenefile(fullfile(pathname, filename));

% check whether the genelist is correct
% pwpath is the folder with code, data and the MENGA*.m
genelabel = checkgenelist(genelabel,pwpath);


%_______________________________________________________________________
% @(#)MENGA    King's College & UNIPD - May 2015
