% MENGA_SETSETTING
disp(' ')
disp('|-------------------------------------------------------------------|')
disp('|                        SELECT SETTING                             |');
disp('|-------------------------------------------------------------------|')

%% LOAD RISTROI
%listroi
[fileroi, pathname] = uigetfile('*.mat', 'Select region list for the analysis',fullfile(phwdUtility,'LISTROI','listroi.mat'));
if isequal(fileroi,0)
    load('listroi.mat')
    disp('Default region list loaded')
else
    disp(['User selected ', fullfile(pathname, fileroi)])
    load(fullfile(pathname, fileroi))
end



%% GENE  INPUT DATA
% NOTE: THERE MUST BE A GENE FILE. IF NOT = EXIT
[filegene, pathgene] = uigetfile('*.txt', 'Select gene list for the analysis',phwdUtility);
if isequal(filegene,0)
    disp('No gene list file loaded: exiting MENGA...')
    MENGA_rmpath;
    MENGA_farewell;
%     break
else
    disp(['User selected ', fullfile(pathgene, filegene)])
end

% create gene list file as: format: genelabel{x} =['name'];
genelabel = loadgenefile(fullfile(pathgene, filegene));

% check whether the genelist is correct
% pwpath is the folder with code, data and the MENGA*.m
genelabel = checkgenelist(genelabel,pwpath);


%_______________________________________________________________________
% @(#)MENGA    King's College & UNIPD - May 2015
