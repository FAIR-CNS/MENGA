
%=======================================================================
%						-MENGA run
%=======================================================================
%% CORR TYPE
% Pearson's correlation
typecor = 'Pearson';

%% DATA LOADING AND REMAPPING in ALLEN SPACE

%importing image to donor space
img2don = MappingImage2Donors(pwpath,folderImage,listroi,windowsize,mask);

if isempty(img2don)
    disp('Image folder is empty: exiting MENGA...')
    return
end

%importing genomic data
gen2don = LoadGenomicData(pwpath,genelabel,listroi);

% nr image loaded = nr of rows in expression matrix in any donor
nrimg = size(img2don(1).exp,1);
img2don_full = img2don;

for j = 1:nrimg
    
    img2don = reduceImg2don(img2don_full,j);
    image_name = img2don(1).info.image_name{j}; % name of the image is present in any donor
    fprintf(['\nAnalyzing image ',image_name,'...\n'])
    
    %% AUTO-CORRELATION GENE
    [statautogen, tabautogen] = AutoCorrelation(gen2don,typecor);
    
    %% AUTO-CORRELATION IMAGE
    [statautoimg, tabautoimg] = AutoCorrelation(img2don,typecor);
    
    %% CROSS-CORRELATION - UNIVARIATE
    [statcorr, tabcorr, direc] = CorrelateImageGenomic(img2don,gen2don);
    
    %% CROSS-CORRELATION - MULTIPLE
    pvalue =true;
    [tabcorrMulti,pvalueMulti,dataused,direcMulti] = CorrelateImageGenomicMultivariate(img2don,gen2don,pvalue);
    
    %% DISPLAY RESULTS
    displayResults(statautogen,statautoimg,statcorr,tabcorrMulti,pvalueMulti,genelabel,direc,direcMulti)
    
    %% SAVE RESULTS
    % SAVE in folderImage, creating a folder
    fileResults = ['RESULTS_',char(image_name(1:end-4))]; % need to eliminate the extension
    folderResults = fullfile(folderImage,fileResults);
    mkdir(folderResults);
    saveResults(statautogen,statautoimg,statcorr,tabcorrMulti,pvalueMulti,genelabel,tabautogen,gen2don,dataused,fileResults,folderResults,namelistroi,filemask,fileroi,windowsize,direc,direcMulti)
    
    % SAVE mat
    filename = fullfile(folderResults,[fileResults,'.mat']);
    save(filename,'gen2don','img2don','genelabel','listroi','namelistroi','mask','stat*','tab*','typecor','windowsize','pvalueMulti','direc','direcMulti')
    
end

%_______________________________________________________________________
% @(#)MENGA    King's College & UNIPD - May 2015