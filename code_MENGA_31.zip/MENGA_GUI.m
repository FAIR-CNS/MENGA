function varargout = MENGA_GUI(varargin)
% MENGA_GUI MATLAB code for MENGA_GUI.fig
%      MENGA_GUI, by itself, creates a new MENGA_GUI or raises the existing
%      singleton*.
%
%      H = MENGA_GUI returns the handle to a new MENGA_GUI or the handle to
%      the existing singleton*.
%
%      MENGA_GUI('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in MENGA_GUI.M with the given input arguments.
%
%      MENGA_GUI('Property','Value',...) creates a new MENGA_GUI or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before MENGA_GUI_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to MENGA_GUI_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help MENGA_GUI

% Last Modified by GUIDE v2.5 21-May-2015 22:25:53


% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
    'gui_Singleton',  gui_Singleton, ...
    'gui_OpeningFcn', @MENGA_GUI_OpeningFcn, ...
    'gui_OutputFcn',  @MENGA_GUI_OutputFcn, ...
    'gui_LayoutFcn',  [] , ...
    'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT

% --- Executes just before MENGA_GUI is made visible.
function MENGA_GUI_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to MENGA_GUI (see VARARGIN)

% Choose default command line output for MENGA_GUI
handles.output = hObject;
axes(handles.axes1)
% imshow('MENGA.jpg')
im = imread('MENGA.jpg');
image(im);
axis off;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes MENGA_GUI wait for user response (see UIRESUME)
% uiwait(handles.figure1);

%=======================================================================
%				-setting the path
%=======================================================================

MENGA_setpath;

handles.phwdUtility = phwdUtility; % path of UTILITY
handles.pwpath = pwpath; % path of MENGA
guidata(hObject, handles);

%=======================================================================
%				-MENGA settings
%=======================================================================

disp(' ')
disp('SELECT SETTING ...');


%% MENGA BEGIN - setsetting

% --- Outputs from this function are returned to the command line.
function varargout = MENGA_GUI_OutputFcn(hObject, eventdata, handles)
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in RegionList.
function RegionList_Callback(hObject, eventdata, handles)
% hObject    handle to RegionList (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

[fileroi, pathname] = uigetfile('*.mat', 'Select region list for the analysis',fullfile(handles.phwdUtility,'LISTROI','listroi.mat'));

if isequal(fileroi,0)
    fileroi = 'listroi.mat';
    handles = guidata(hObject);
    handles.path_roi=fullfile(handles.phwdUtility,'LISTROI','listroi.mat');
    load('listroi.mat')
    disp('Default region list loaded')
else
    disp(['> ROI LIST    ', fullfile(pathname, fileroi)])
    handles.path_roi=[pathname fileroi];
    load(fullfile(pathname, fileroi))
end
handles.listroi = listroi;
handles.namelistroi = namelistroi;
handles.fileroi = fileroi;

% select subset of path to show
pathshow = regexp(handles.path_roi, filesep, 'split');
set(handles.text6,'String',[myStringJoin(pathshow(1:3),filesep),filesep,' [...] ',filesep,myStringJoin(pathshow(end-2:end),filesep)]); % showing FullPathROI
guidata(hObject,handles);

% --- Executes on button press in RegionList.
function Mask_Callback(hObject, eventdata, handles)
% hObject    handle to Mask (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

[filemask, pathname] = uigetfile('*.mat', 'Select mask for the analysis',fullfile(handles.phwdUtility,'MASK','MASK_MNI_brain_imfill_LEFT.mat'));

if isequal(filemask,0)
    filemask = 'MASK_MNI_brain_imfill_LEFT.mat';
    handles = guidata(hObject);
    handles.path_mask=fullfile(handles.phwdUtility,'MASK','MASK_MNI_brain_imfill_LEFT.mat');
    load('MASK_MNI_brain_imfill_LEFT.mat')
    disp('Default mask loaded')
else
    disp(['> MASK        ', fullfile(pathname, filemask)])
    handles.path_mask=[pathname filemask];
    load(fullfile(pathname, filemask))
end

handles.mask = mask;
handles.filemask = filemask;

% select subset of path to show
pathshow = regexp(handles.path_mask, filesep, 'split');
set(handles.text7,'String',[myStringJoin(pathshow(1:3),filesep),filesep,' [...] ',filesep,myStringJoin(pathshow(end-2:end),filesep)]); % showing FullPathMask
guidata(hObject,handles);

% --- Executes on button press in RegionList.
function ImageFolder_Callback(hObject, eventdata, handles)
% hObject    handle to ImageFolder (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

folderImage = uigetdir(pwd,'Select folder of the image to analyze');

if isequal(folderImage,0)
    disp('No gene list file loaded: exiting MENGA...')
    MENGA_rmpath;
    MENGA_farewell;
    close all force
    return
else
    disp(['> WORKING in  ', folderImage])
    handles.path_image=[folderImage];
end

handles.folderImage = folderImage;

% select subset of path to show
pathshow = regexp(handles.path_image, filesep, 'split');

set(handles.text8,'String',[myStringJoin(pathshow(1:3),filesep),filesep,' [...] ',filesep,myStringJoin(pathshow(end-2:end),filesep)]); % showing FullPathImage
guidata(hObject,handles);


% --- Executes on button press in RegionList.
function GeneList_Callback(hObject, eventdata, handles)
% hObject    handle to GeneList (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

[filename, pathname] = uigetfile('*.txt', 'Select gene list for the analysis',handles.phwdUtility);

if isequal(filename,0)
    disp('No gene list file loaded: exiting MENGA...')
    MENGA_rmpath;
    MENGA_farewell;
    close all force
    return
else
    disp(['> GENE LIST   ', fullfile(pathname, filename)])
    handles.path_gene=[pathname filename];
end

% select subset of path to show
pathshow = regexp(handles.path_gene, filesep, 'split');

set(handles.text9,'String',[myStringJoin(pathshow(1:3),filesep),filesep,' [...] ',filesep,myStringJoin(pathshow(end-2:end),filesep)]); % showing FullPathGene
guidata(hObject,handles);



% --- Executes during object creation, after setting all properties.
function editWindowSize_CreateFcn(hObject, eventdata, handles)
% hObject    handle to editWindowSize (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function editWindowSize_Callback(hObject, eventdata, handles)
% hObject    handle to editWindowSize (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of editWindowSize as text
%        str2double(get(hObject,'String')) returns contents of editWindowSize as a double
windowsize = str2double(get(handles.editWindowSize,'String'));
handles.windowsize = windowsize;
guidata(hObject,handles);


% --- Executes on button press in Start_button.
function Start_button_Callback(hObject, eventdata, handles)
% hObject    handle to Start_button (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%=======================================================================
%				-MENGA run
%=======================================================================
% MENGA_run: it loads image and gene data, and it runs the analysis

handles = guidata(hObject);

if not(isfield(handles,'path_roi'))
    msg =  msgbox(['No region list selected'],'Empty!','warn');
    return
elseif not(isfield(handles,'path_mask'))
    msg =  msgbox(['No mask selected'],'Empty!','warn');
    return
elseif not(isfield(handles,'path_image'))
    msg =  msgbox(['No folder image selected'],'Empty!','warn');
    return
elseif not(isfield(handles,'path_gene'))
    msg =  msgbox(['No gene list selected'],'Empty!','warn');
    return
elseif not(isfield(handles,'windowsize'))
    msg =  msgbox(['Insert an integer value for window size'],'Empty!','warn');
    return
elseif isfield(handles,'windowsize') && (handles.windowsize < 0 || not(rem(handles.windowsize,1)==0))
    msg =  msgbox(['Insert an integer value for window size'],'Error!','warn');
    return
else
    
    % LOAD GENE FILES
    % create gene list file as: format: genelabel{x} =['name'];
    
    genelabel = loadgenefile(handles.path_gene);
    pwpath = handles.pwpath;
    mask = handles.mask;
    listroi = handles.listroi;
    namelistroi = handles.namelistroi;
    folderImage = handles.folderImage;
    windowsize = handles.windowsize;
    filemask = handles.filemask;
    fileroi = handles.fileroi;
    
    % check whether the genelist is correct
    % pwpath is the folder with code, data and the MENGA*.m
    genelabel = checkgenelist(genelabel,pwpath);
    
    disp(['> WINDOW SIZE ', num2str(windowsize)])
    disp(' ')
    disp('RUNNING ANALYSIS ...');
    
    
    MENGA_run;
    
    %=======================================================================
    %				-remove path
    %=======================================================================
    MENGA_rmpath;
    
    
    %=======================================================================
    %    				 Farewell
    %=======================================================================
    MENGA_farewell;
    close all force
    
end

% --- Executes when user attempts to close YourGuiName.
function figure1_CloseRequestFcn(hObject, eventdata, handles)
% hObject    handle to YourGuiName (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
selection = questdlg('Close MENGA?',...
    'Close Request Function',...
    'Yes','No','Yes');
switch selection,
    case 'Yes',
        MENGA_rmpath;
        MENGA_farewell;
        delete(hObject);
        
    case 'No'
        return
end

%_______________________________________________________________________
% @(#)MENGA    King's College & UNIPD - May 2015
