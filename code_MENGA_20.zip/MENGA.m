% MENGA

% Startup routine for MENGA
%
% MENGA: Multimodal Environment for Neuroimaging and Genomic Analysis
%
% MENGA (the collection of files listed by Contents.m) is copyright under
% the GNU general public license (GPLv3). 
% 
% The transcriptome genomic mRNA data are made freely available by the 
% Allen Institute for Brain Science. Data were downloaded from the Allen 
% Human Brain Atlas (http://human.brain-map.org/, Hawrylycz et al, Nature, 
% 2012).
% 
% MENGA written by 
% Paul Expert, Gaia Rizzo and Mattia Veronese
%
% Version 1.0 
% 2015, May 20th

%
clc
close all
clear 

%=======================================================================
%                   Welcome
%=======================================================================

MENGA_welcome; 

MENGA_GUI

%_______________________________________________________________________
% @(#)MENGA    King's College & UNIPD - May 2015
