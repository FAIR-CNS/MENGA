function MENGA_welcome

%-------------------------------------------------------------------------%
disp('|===================================================================|')
disp('|                        WELCOME to MENGA                           |');
disp('|                                                                   |')
disp('|                                                                   |')
disp('|    Multimodal Environment for Neuroimaging and Genomic Analysis   |')
disp('|                                                                   |')
disp('|===================================================================|')
disp(' ')
disp('       Created by Gaia Rizzo, Paul Expert & Mattia Veronese')
disp(' ')
disp('               mRNA data source: Allen Human Brain Atlas ')
disp('                 (http://human.brain-map.org/)')
disp(' ')
disp('--------------------------------------------------------------------')
disp(' ')

end

%_______________________________________________________________________
% @(#)MENGA    King's College & UNIPD - May 2015