List of regions of interest to use to sample genomic and image data.

- listroi: ABA index with macro regions of interest (derived by "coarse" level but reduced from a PET point of view, i.e. one thalamus, one brainstem, ...). It contains also namelistroi with the name of the regions.

- listroifull: "coarse" ABA indexes. It contains also namelistroi with the name of the regions. 

- listroistruct: "structure" ABA indexes. It contains also namelistroi with a numbered list of the regions. 
