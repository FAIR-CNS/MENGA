% It prints on the command windows the results statistics

% input:
% tabgene: 2D matrix of statistics on correlation of genes, 5 x nrgenes
% tabimg: 1D matrix of statistics on correlation of the image, 5 x 1
% tabuni: 2D matrix of statistics on univariate correlation, 5 x nrgenes
% tabmulti: 1D matrix of statistics on multivariate correlation, 5 x 1
% pvalue: 1D likelihood chance, 5 x 1
% genelabel: string with gene list
% direc: 2D matrix with directionality of univariate correlation, 6 x
% nrgenes
% direcMulti: 2D matrix with directionality of multivariate correlation, 1
% x nrgenes

function displayResults(tabgene,tabimg,tabuni,tabmulti,pvalue,genelabel,direc,direcMulti)

nrgene = size(tabgene,2);
fprintf('\n')
fprintf('RESULTS from current analysis\n')
fprintf(['The average IMAGE auto-correlation is: ',num2str(tabimg(1,1),3),' +/- ',num2str(tabimg(2,1),3),'\n'])
fprintf('\n')
for i=1:nrgene
    fprintf(['%%%%%% GENE ',genelabel{i}, ' %%%%%%','\n'])
    fprintf(['The average GENOMIC auto-correlation is: %.3f +/- %.3f \n'],tabgene(1,i),tabgene(2,i))
    fprintf(['The average UNIVARIATE cross-correlation is: %.3f +/- %.3f \n'],tabuni(1,i),tabuni(2,i))
    fprintf(['\t Direction of the univariate correlation: %d positive correlations out of 6','\n'],length(direc(:,i)>0))
    fprintf(['The MULTIVARIATE cross-correlation is: %.3f (chance likelihood = %2.0f%%)','\n'],tabmulti(1,i),pvalue(1,i)*100)
    fprintf(['\t Direction of the multivariate correlation: %+.0f\n\n'],direcMulti(i))
    
end
