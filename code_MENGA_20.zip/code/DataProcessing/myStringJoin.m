function joinedStr = myStringJoin(c, aDelim)
%myStringJoin  Modified from STRJOIN
%   Join cell array of strings into single string
%
%   S = myStringJoin(C, DELIMITER) constructs S by linking each element of 
%   C with the elements of DELIMITER. DELIMITER is a string (filesep) 
%

numStrs = numel(c);

% Allocate a cell to join into - the first row will be C and the second, D.
joinedCell = cell(2, numStrs);
joinedCell(1, :) = reshape(c, 1, numStrs);

% delimiter must be cell
theDelim = cellstr(aDelim);

% Join.
joinedCell(2, 1:numStrs-1) = theDelim;
joinedStr = [joinedCell{:}];

end

%_______________________________________________________________________
% @(#)MENGA    King's College & UNIPD - May 2015