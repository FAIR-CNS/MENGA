% img = loadImage(filename, mask)

% the function load a NIfTI image and check if it is in MNI MRIcro standard

% input:
% imagefolder: string with the name of the folder containing the images 
% filename: string with the name of the image to load
% mask: 3D matrix, values 0-1

% output:
% img_out: 3D matrix (size: 181, 217, 181) in z-score. Values are NaN
% outside the mask

function img_out = loadimage(imagefolder,filename,mask)

nii = load_nii(fullfile(imagefolder,filename));
img_in = double(nii.img);
img_ok = checksize(img_in);

imask = (mask>0);

mimg = nanmean(img_ok(imask));
sdimg = nanstd(img_ok(imask));

img_okz = (img_ok-mimg)./sdimg;

% redundant = it sets to NaN all the elements outside the mask
img_out = ones(size(mask))*NaN;
img_out(imask) = img_okz(imask);

disp(['Image ',filename,' loaded.'])

end