% Auto-correlation: squared correlation R^2
%
% input:
% struct: structure, either img2don or gen2don
% typecor: string, 'Pearson','Spearman', ...
%
% output:
% stat: 2D matrix, 5 x nrimage/nrgene with mean/SD/CV/min/max of
% correlation values
% sqcor: 3D matrix, containing the auto-correlation. 6 x 6 x nrelements.
% It has sense only at % structure or coarse level.

function [stat, sqcor] = AutoCorrelation(struct,typecor)

dim = size(struct(1).exp,1); % nr genes or nr images
nrdonor = size(struct,2);
sqcor = zeros(nrdonor,nrdonor,dim);
stat = zeros(5,dim);

% index for the inferior triangular matrix
matTr = tril(ones(nrdonor,nrdonor),-1);
indxtriang = find(matTr);

for k=1:dim
    for i=1:nrdonor
        for j=1:nrdonor
            iok = (~isnan(struct(i).exp(k,:))&~isnan(struct(j).exp(k,:)));
            if not(any(iok)),continue,end
            valcor = corr([struct(i).exp(k,iok)',struct(j).exp(k,iok)'],'type',typecor);
            sqcor(j,i,k) = valcor(1,2)^2;    
        end
    end
    
    corsing = squeeze(sqcor(:,:,k));
    valsing = tril(corsing,-1);
    valsing = valsing(indxtriang);
    
    % index for the inferior triangular matrix
    
    if any(valsing)
        stat(1,k) = mean(valsing(valsing>0));
        stat(2,k) = std(valsing(valsing>0));
        stat(3,k) = stat(2,k)/stat(1,k)*100;
        stat(4,k) = min(valsing(valsing>0));
        stat(5,k) = max(valsing(valsing>0));
        if any(valsing<=0)
            fprintf(['Warning auto correlation: there are ',num2str(length(find(valsing<=0))),' negative R-squared','\n'])
        end
    else
        fprintf(['Warning auto correlation: there are NO positive R-squared','\n'])
    end
    clear corsing valsing
end
