function pval = CalculateLikelihood(X,YY,weights,sqcor,nboot)

Xnew = zeros(size(X));
bootstat = zeros(nboot,1);

for i = 1:nboot
    for j=1:size(X,2)
        Xnew(:,j) = datasample(X(:,j),size(X,1),'Replace',false);
    end

    [coeff, score, latent, ts, explained] = pca(Xnew);
    tot = explained(1);
    ind = 1;
    while tot<95
        ind = ind+1;
        tot = tot+explained(ind);
    end
    nPC = ind;
    PCs = score(:,1:nPC);
    PCs(:,nPC+1) = ones(size(X,1),1);
    
    bootstat(i,1) = CalculateR2(PCs,YY,weights);
    clear PCs
end

nrok = length(find(bootstat>sqcor));

pval = nrok/nboot;
